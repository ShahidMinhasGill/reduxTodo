export const ActionTypes = {
    INCREMENT: "INCREMENT",
    DECREMENT: "DECREMENT",
    AddData: "ADD_DATA",
    DeleteData: "DELETE_DATA",
    EditItem: "EDIT_DATA",
};